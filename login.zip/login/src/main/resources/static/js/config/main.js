const LOCAL_STORAGE_LOGIN_TOKEN_NAME = "userid";
const ROOT_PATH = "/home/geotzinos/project"