package regenaration.team4.services;

import org.springframework.stereotype.Service;
import regenaration.team4.Registration;
import regenaration.team4.entities.Citizen;
import regenaration.team4.entities.User;
import regenaration.team4.repositories.CitizenRepository;
import regenaration.team4.repositories.UserRepository;
import regenaration.team4.security.Role;

@Service
public class RegistrationService {

    private final CitizenRepository citizenRepository;
    private final UserRepository userRepository;

    public  RegistrationService(CitizenRepository citizenRepository,UserRepository userRepository){
        this.citizenRepository = citizenRepository;
        this.userRepository = userRepository;
    }
    public Registration register( Registration registration){
        User user = new User(registration.getUsername(),registration.getPassword(), Role.CITIZEN);
        userRepository.save(user);
        Citizen citizen = new Citizen(registration.getAmka(),registration.getName(),registration.getSurname(),registration.getEmail(),registration.getPhone());
        citizen.setUser(user);
        citizenRepository.save(citizen);
        return registration;
    }
}
