package regenaration.team4.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import regenaration.team4.Registration;
import regenaration.team4.repositories.CitizenRepository;
import regenaration.team4.repositories.UserRepository;
import regenaration.team4.services.RegistrationService;

@RestController
public class RegistrationController {

    private RegistrationService registrationService;
    private final CitizenRepository citizenRepository;
    private final UserRepository userRepository;

    public RegistrationController(@Autowired RegistrationService registrationService,CitizenRepository citizenRepository, UserRepository userRepository) {
        this.citizenRepository = citizenRepository;
        this.userRepository = userRepository;
        this.registrationService = registrationService;
    }

    @PostMapping("/api/register")
    public Registration newRegistration(@RequestBody Registration registration){
        return registrationService.register(registration);
    }

}