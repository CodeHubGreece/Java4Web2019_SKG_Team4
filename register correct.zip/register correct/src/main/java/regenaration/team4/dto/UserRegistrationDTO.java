package regenaration.team4.dto;


import regenaration.team4.security.Role;

public class UserRegistrationDTO {


    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setCitizen_password(String citizen_password) {
        this.citizen_password = citizen_password;
    }

    public void setCitizenId(Long citizenId) {
        this.citizenId = citizenId;
    }

    public void setCitizen_name(String citizen_name) {
        this.citizen_name = citizen_name;
    }

    public void setCitizen_lastname(String citizen_lastname) {
        this.citizen_lastname = citizen_lastname;
    }

    public void setCitizen_email(String citizen_email) {
        this.citizen_email = citizen_email;
    }

    public void setCitizen_phone(String citizen_phone) {
        this.citizen_phone = citizen_phone;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    private Long userId;
    private String username;
    private String citizen_password;
    private Long citizenId;
    private String citizen_name;
    private String citizen_lastname;
    private String citizen_email;
    private String citizen_phone;
    private String amka;

    public Long getUserId() {
        return userId;
    }

    public String getUsername() {
        return username;
    }

    public String getCitizen_password() {
        return citizen_password;
    }

    public Long getCitizenId() {
        return citizenId;
    }

    public String getCitizen_name() {
        return citizen_name;
    }

    public String getCitizen_lastname() {
        return citizen_lastname;
    }

    public String getCitizen_email() {
        return citizen_email;
    }

    public String getCitizen_phone() {
        return citizen_phone;
    }

    public Role getRole() {
        return role;
    }

    private Role role;

    public String getAmka() {
        return amka;
    }

    public void setAmka(String amka) {
        this.amka = amka;
    }
}