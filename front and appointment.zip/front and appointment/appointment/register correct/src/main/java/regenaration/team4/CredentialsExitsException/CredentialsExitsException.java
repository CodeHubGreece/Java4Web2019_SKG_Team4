package regenaration.team4.CredentialsExitsException;

public class CredentialsExitsException extends RuntimeException {
    // runtimeException is the superclass of those exceptions that can be thrown during the normal operation of the
    // Java Virtual Machine.
        public CredentialsExitsException(String username, String email, String phone) {
            super("One or more of your credentials (" + username + ", " + email + ", " + phone + ") already exist.");
        }

}

