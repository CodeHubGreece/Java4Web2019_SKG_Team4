package regenaration.team4.security;

public enum Role {
    DOCTOR,
    CITIZEN
}
