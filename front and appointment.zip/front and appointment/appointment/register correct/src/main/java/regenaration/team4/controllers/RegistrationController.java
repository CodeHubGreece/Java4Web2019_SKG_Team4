package regenaration.team4.controllers;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import regenaration.team4.dto.UserRegistrationDTO;
import regenaration.team4.entities.Citizen;
import regenaration.team4.services.RegistrationService;

@RestController // automatically serializes return objects into HttpResponse.
public class RegistrationController {

    @Autowired // This annotation allows Spring to resolve and inject collaborating beans into your bean.
    RegistrationService registrationService;


    @PostMapping("api/registration") //@PostMapping annotated methods handle the HTTP POST requests matched with given URI expression.
    public Citizen newRegistration(@RequestBody UserRegistrationDTO userRegistrationDTO) {
        return registrationService.newRegistration(userRegistrationDTO);
    }
}
//@RequestBody annotation maps the HttpRequest body to a transfer or domain object,
//enabling automatic deserialization of the inbound HttpRequest body onto a Java object.