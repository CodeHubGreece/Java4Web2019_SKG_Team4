package regenaration.team4.repositories;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import regenaration.team4.entities.Doctor;
import regenaration.team4.entities.Specialty;

import java.util.List;

@Repository
public interface DoctorRepository extends JpaRepository<Doctor, Integer> {
    List<Doctor> findBySpecialty(Specialty specialty);
}