package regenaration.team4.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import regenaration.team4.security.Role;
import regenaration.team4.services.LoggedInService;

import java.security.Principal;


@RestController
public class LoggedInController {

    @Autowired
    LoggedInService loggedInService;
    //@GetMapping annotated methods handle the HTTP GET requests matched with given URI expression.
    @GetMapping("/api/login")
    public Role userRole(Principal principal) {
        return loggedInService.userRole(principal);
    }
}
