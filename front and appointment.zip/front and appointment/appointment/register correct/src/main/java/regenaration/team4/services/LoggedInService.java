package regenaration.team4.services;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import regenaration.team4.entities.User;
import regenaration.team4.repositories.UserRepository;
import regenaration.team4.security.Role;

import java.security.Principal;

@Service
public class LoggedInService {

    @Autowired
    UserRepository userRepository;

    public Role userRole(Principal principal) {
        User loggedInUser = userRepository.findByUsername(principal.getName());
        return loggedInUser.getRole();
    }
}
